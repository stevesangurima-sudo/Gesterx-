package com.gesturex.ai

import java.util.UUID

enum class Reliability(val label: String) {
    HIGH("Fiable (modelo MediaPipe)"),
    MEDIUM("Heurística (menos fiable)"),
    EXPERIMENTAL("Experimental (sin calibrar)")
}

enum class GestureId(val label: String, val rel: Reliability, val movement: Boolean = false) {
    PALM("Palma abierta", Reliability.HIGH),
    FIST("Puño cerrado", Reliability.HIGH),
    THUMB_UP("Pulgar hacia arriba", Reliability.HIGH),
    THUMB_DOWN("Pulgar hacia abajo", Reliability.HIGH),
    PEACE("Signo de paz (también = dos dedos)", Reliability.HIGH),
    INDEX("Índice levantado", Reliability.HIGH),
    THREE("Tres dedos levantados", Reliability.MEDIUM),
    FOUR("Cuatro dedos levantados", Reliability.MEDIUM),
    FINGERS_SPREAD("Mano con los dedos separados", Reliability.EXPERIMENTAL),
    FINGERS_TOGETHER("Mano con los dedos juntos", Reliability.EXPERIMENTAL),
    MOVE_LEFT("Movimiento de la mano a la izquierda", Reliability.EXPERIMENTAL, true),
    MOVE_RIGHT("Movimiento de la mano a la derecha", Reliability.EXPERIMENTAL, true),
    MOVE_UP("Movimiento de la mano hacia arriba", Reliability.EXPERIMENTAL, true),
    MOVE_DOWN("Movimiento de la mano hacia abajo", Reliability.EXPERIMENTAL, true)
}

enum class ActionType(val label: String, val note: String) {
    OPEN_BROWSER("Abrir Google o el navegador", "Parámetro opcional: URL (por defecto google.com)."),
    OPEN_YOUTUBE("Abrir YouTube", "Abre la app si está instalada; si no, youtube.com."),
    OPEN_APP("Abrir una aplicación instalada", "Elige la app en el paso de parámetros."),
    OPEN_CAMERA("Abrir la cámara (no toma foto)", "Solo abre la cámara. Frontal/trasera depende de la app de cámara."),
    PHOTO_AUTO("Intentar tomar una foto automáticamente", "Solo con la pantalla «Activar» abierta. Usa la cámara frontal y guarda en la carpeta de la app. Si no es posible, abre la cámara."),
    OPEN_SETTINGS("Abrir los ajustes del teléfono", "Abre Ajustes mediante intent público."),
    OPEN_URL("Abrir un enlace web", "Parámetro: el enlace."),
    FLASHLIGHT("Encender/apagar la linterna", "Usa CameraManager.setTorchMode. Puede fallar si la cámara trasera está en uso."),
    VOLUME_UP("Subir el volumen", "Volumen multimedia mediante AudioManager."),
    VOLUME_DOWN("Bajar el volumen", "Volumen multimedia mediante AudioManager."),
    NOTIFICATION("Mostrar una notificación", "Parámetro: texto. Requiere permiso de notificaciones (Android 13+)."),
    GO_HOME("Ir a la pantalla de inicio", "Requiere activar el servicio de accesibilidad de GestureX AI."),
    SCREENSHOT("Intentar captura de pantalla", "Requiere el servicio de accesibilidad y Android 9 o superior.")
}

data class ActionConfig(val type: ActionType, val param: String = "", val param2: String = "")

data class Rule(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val gesture: GestureId,
    val steps: List<ActionConfig>,
    val enabled: Boolean = true,
    val minHoldMs: Int = 500,
    val cooldownMs: Int = 3000
)

data class ActionResult(val ok: Boolean, val message: String, val needsUser: Boolean = false)
