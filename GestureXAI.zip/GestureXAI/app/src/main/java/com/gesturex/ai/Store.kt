package com.gesturex.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Guarda reglas y ajustes solo en el almacenamiento local (SharedPreferences). */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("gesturex", Context.MODE_PRIVATE)

    var minScore: Float
        get() = sp.getFloat("min_score", 0.6f)
        set(v) { sp.edit().putFloat("min_score", v).apply() }

    fun loadRules(): List<Rule> {
        val raw = sp.getString("rules", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { parse(arr.getJSONObject(it)) }
        } catch (e: Exception) { emptyList() }
    }

    fun saveRules(rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id); put("name", r.name); put("gesture", r.gesture.name)
                put("enabled", r.enabled); put("hold", r.minHoldMs); put("cooldown", r.cooldownMs)
                put("steps", JSONArray().apply {
                    r.steps.forEach { s ->
                        put(JSONObject().put("type", s.type.name).put("p", s.param).put("p2", s.param2))
                    }
                })
            })
        }
        sp.edit().putString("rules", arr.toString()).commit()
    }

    private fun parse(o: JSONObject): Rule? = try {
        val st = o.getJSONArray("steps")
        val steps = (0 until st.length()).map {
            val s = st.getJSONObject(it)
            ActionConfig(ActionType.valueOf(s.getString("type")), s.optString("p"), s.optString("p2"))
        }
        Rule(o.getString("id"), o.getString("name"), GestureId.valueOf(o.getString("gesture")), steps,
            o.optBoolean("enabled", true), o.optInt("hold", 500), o.optInt("cooldown", 3000))
    } catch (e: Exception) { null }
}
