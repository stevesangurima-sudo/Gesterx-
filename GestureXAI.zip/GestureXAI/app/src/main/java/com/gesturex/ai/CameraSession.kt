package com.gesturex.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Environment
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/** Cámara frontal con vista previa + análisis de fotogramas (en memoria) + captura de fotos propia. */
class CameraSession(private val context: Context, private val owner: LifecycleOwner) {
    private var provider: ProcessCameraProvider? = null
    private var capture: ImageCapture? = null
    private val exec: ExecutorService = Executors.newSingleThreadExecutor()

    fun start(view: PreviewView, onBitmap: (Bitmap) -> Unit, onError: (String) -> Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val p = future.get(); provider = p; p.unbindAll()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy ->
                    try {
                        val bmp = proxy.toBitmap()
                        val rot = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
                        val upright = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, rot, true)
                        val mirror = Matrix().apply { postScale(-1f, 1f) }
                        onBitmap(Bitmap.createBitmap(upright, 0, 0, upright.width, upright.height, mirror, true))
                    } finally { proxy.close() }  // los fotogramas no se guardan ni se envían
                }
                val cap = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                try {
                    p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis, cap)
                    capture = cap
                } catch (e: Exception) {
                    // Algunos dispositivos no admiten 3 casos de uso a la vez: sin captura propia.
                    p.unbindAll()
                    p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
                    capture = null
                }
            } catch (e: Exception) { onError("No se pudo iniciar la cámara: ${e.message}") }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stop() { provider?.unbindAll(); exec.shutdown() }

    suspend fun takePhoto(): ActionResult {
        val cap = capture ?: return ActionResult(false, "Este dispositivo no admite captura simultánea con el análisis. No se tomó foto.")
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "GestureX").apply { mkdirs() }
        val file = File(dir, "IMG_${System.currentTimeMillis()}.jpg")
        return suspendCancellableCoroutine { cont ->
            cap.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(),
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(o: ImageCapture.OutputFileResults) {
                        cont.resume(ActionResult(true, "Foto guardada en ${file.absolutePath}"))
                    }
                    override fun onError(e: ImageCaptureException) {
                        cont.resume(ActionResult(false, "Error al capturar: ${e.message}"))
                    }
                })
        }
    }
}
