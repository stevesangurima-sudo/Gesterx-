package com.gesturex.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Solo ejecuta acciones globales (inicio, captura). No lee el contenido de la pantalla. */
class GestureAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: GestureAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
}
