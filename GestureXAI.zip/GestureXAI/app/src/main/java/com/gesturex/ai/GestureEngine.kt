package com.gesturex.ai

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import kotlin.math.abs
import kotlin.math.hypot

data class Frame(val handPresent: Boolean, val gestures: Set<GestureId>, val rawLabel: String, val score: Float)

/** Reconocimiento 100 % local con MediaPipe Gesture Recognizer + heurísticas sobre los 21 puntos de la mano. */
class GestureEngine(
    context: Context,
    private val minScore: () -> Float,
    private val onFrame: (Frame) -> Unit,
    onError: (String) -> Unit
) {
    private var recognizer: GestureRecognizer? = null
    private var lastTs = 0L
    private val history = ArrayDeque<Triple<Long, Float, Float>>()
    val ready: Boolean get() = recognizer != null

    init {
        try {
            val base = BaseOptions.builder().setModelAssetPath("gesture_recognizer.task").build()
            val opts = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { res, img -> handle(res, img) }
                .setErrorListener { e -> onError("Error del modelo: ${e.message}") }
                .build()
            recognizer = GestureRecognizer.createFromOptions(context, opts)
        } catch (e: Exception) {
            onError("No se pudo cargar el modelo (¿falta assets/gesture_recognizer.task?): ${e.message}")
        }
    }

    fun submit(bitmap: Bitmap) {
        val r = recognizer ?: return
        var ts = SystemClock.uptimeMillis()
        if (ts <= lastTs) ts = lastTs + 1
        lastTs = ts
        r.recognizeAsync(BitmapImageBuilder(bitmap).build(), ts)
    }

    fun close() { recognizer?.close(); recognizer = null }

    private class P(val x: Float, val y: Float)
    private fun d(a: P, b: P) = hypot(a.x - b.x, a.y - b.y)

    @Suppress("UNUSED_PARAMETER")
    private fun handle(res: GestureRecognizerResult, img: MPImage) {
        val lms = res.landmarks().firstOrNull()
        if (lms == null || lms.size < 21) {
            history.clear()
            onFrame(Frame(false, emptySet(), "", 0f)); return
        }
        val cat = res.gestures().firstOrNull()?.firstOrNull()
        val score = cat?.score() ?: 0f
        val name = cat?.categoryName() ?: ""
        val out = mutableSetOf<GestureId>()

        if (score >= minScore()) when (name) {
            "Open_Palm" -> out += GestureId.PALM
            "Closed_Fist" -> out += GestureId.FIST
            "Thumb_Up" -> out += GestureId.THUMB_UP
            "Thumb_Down" -> out += GestureId.THUMB_DOWN
            "Victory" -> out += GestureId.PEACE
            "Pointing_Up" -> out += GestureId.INDEX
        }

        val p = lms.map { P(it.x(), it.y()) }
        // Dedo extendido: la punta está más lejos de la muñeca que la articulación PIP (independiente de la rotación).
        fun ext(tip: Int, pip: Int) = d(p[tip], p[0]) > d(p[pip], p[0]) * 1.1f
        val index = ext(8, 6); val middle = ext(12, 10); val ring = ext(16, 14); val pinky = ext(20, 18)
        val thumb = d(p[4], p[17]) > d(p[3], p[17]) * 1.1f
        if (index && middle && ring && !pinky) out += GestureId.THREE
        if (index && middle && ring && pinky && !thumb) out += GestureId.FOUR
        if (index && middle && ring && pinky) {
            val size = d(p[0], p[9]).coerceAtLeast(0.01f)
            val gap = (d(p[8], p[12]) + d(p[12], p[16]) + d(p[16], p[20])) / 3f / size
            out += if (gap > 0.28f) GestureId.FINGERS_SPREAD else GestureId.FINGERS_TOGETHER
        }

        // Movimiento de la muñeca en ~0,5 s (imagen espejada, como la vista previa).
        val now = SystemClock.uptimeMillis()
        history.addLast(Triple(now, p[0].x, p[0].y))
        while (history.isNotEmpty() && now - history.first().first > 500) history.removeFirst()
        if (history.size >= 4) {
            val dx = history.last().second - history.first().second
            val dy = history.last().third - history.first().third
            if (abs(dx) > 0.30f && abs(dy) < abs(dx) * 0.5f) {
                out += if (dx < 0) GestureId.MOVE_LEFT else GestureId.MOVE_RIGHT; history.clear()
            } else if (abs(dy) > 0.30f && abs(dx) < abs(dy) * 0.5f) {
                out += if (dy < 0) GestureId.MOVE_UP else GestureId.MOVE_DOWN; history.clear()
            }
        }
        onFrame(Frame(true, out, name, score))
    }
}
